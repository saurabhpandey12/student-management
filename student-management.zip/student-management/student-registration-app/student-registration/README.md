# StudentRegistration

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.21.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


# once the application screen will get open you have to login using either google or basic authentication so after getting login token will get generate and the toke  will get saved 

# routing details
first you have to route to home screen the to reagister student form 

http://localhost:4200/student/students  using this route will get all the register students
http://localhost:4200/student/registration-form   to register new students
http://localhost:4200/profile to login using google

for updating the students details i have implemented updating functionality 

http://localhost:4200/student/update/studentId

and to view student details 


http://localhost:4200/student/view-details/studentId



# application guideline

while doing registration few inputs are manadatory
like rollnumber which should me unique 
and first name last name 
email
phone number
alternate number is optional

and address is manadatory


