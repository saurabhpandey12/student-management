import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { StudentRegistrationFormComponent } from './component/student-registration-form/student-registration-form.component';
import { ProfileComponent } from './profile/profile.component';
import { SearchComponent } from './search/search/search.component';
import { UpdateComponent } from './search/update/update.component';


const routes: Routes = [{
  path:'login',
  component:LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},
{
  path:'profile',
  component:ProfileComponent
},
{
  path:'student-registration',
  component:StudentRegistrationFormComponent,
  canActivate:[AuthGuard]
},
  { path: 'student', loadChildren: () => import('./student/student.module').then(m => m.StudentModule) ,
  canActivate:[AuthGuard]}
  ,
  {
    path:'profile',
    component:ProfileComponent
  },
  { path: "find", redirectTo: "search" },
  { path: "search", component: SearchComponent },
  {
    path:'update/:id',
    component:UpdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
