import { Component, OnInit } from '@angular/core';
import { SocialAuthService, SocialUser } from 'angularx-social-login';
import { TokenStorageService } from './auth/auth-service/token-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  private roles: string[] = [];
  isLoggedIn = false;
  showAdminBoard = false;
  showModeratorBoard = false;
  username?: string;

  constructor(private tokenStorageService: TokenStorageService,private authService: SocialAuthService) { }
user:object


  ngOnInit(): void {

 

    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      const user = this.tokenStorageService.getUser();
      this.roles = user.roles;

      this.showAdminBoard = this.roles.includes('ROLE_ADMIN');
      this.showModeratorBoard = this.roles.includes('ROLE_MODERATOR');

      this.username = user.username;
    }

    this.authService.authState.subscribe((user) => {
      this.user = user;
      console.log(user);
    });
  }

  logout(): void {
    this.tokenStorageService.signOut();
    window.location.reload();
  }
flag=true;
  signOut(){
    this.flag=false
    this.authService.signOut();
  }

  onRouteHideFlag=true;
  hide(){
    this.onRouteHideFlag=false;
  }
  
}
