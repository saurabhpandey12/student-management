import { Injectable, OnInit } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { SocialAuthService } from 'angularx-social-login';
import { Observable } from 'rxjs';
import { AuthService } from './auth-service/auth.service';
import { TokenStorageService } from './auth-service/token-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate,OnInit {
  constructor(public auth: AuthService, public router: Router,private tokenStorageService: TokenStorageService,private socialAuthService:SocialAuthService) {}
  flag=false;
  ngOnInit(): void {
    this.socialAuthService.authState.subscribe((user) => {
      this.user = user;
      this.flag=true
      console.log(user);
    });
  }
  isLoggedIn:boolean
  user:object
  canActivate(): boolean {
   
    this.isLoggedIn = !!this.tokenStorageService.getToken();
    if (!this.isLoggedIn ) {
      this.router.navigate(['login']);
      return false;
    }else {
      return true;
    }
    // return true;
  }
}
