import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-registration-form',
  templateUrl: './student-registration-form.component.html',
  styleUrls: ['./student-registration-form.component.css']
})
export class StudentRegistrationFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
