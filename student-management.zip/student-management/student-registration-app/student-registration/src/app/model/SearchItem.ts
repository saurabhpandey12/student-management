class SearchItem {
    constructor(
      public name: string,
      public artist: string,
      public link: string,
      public thumbnail: string,
      public artistId: string
    ) {}
  }