export class State {
    constructor(public id: string, public cityId: string, public name: string) { }
  }
  