import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const API_URI="http://localhost:8080/student-service/v1/searchStudentsBasedOnFields"

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http:HttpClient){}

  searchStudentBasedOnField(searchKey:string){
    return this.http.get(API_URI+'/'+searchKey);
  }
  

}
