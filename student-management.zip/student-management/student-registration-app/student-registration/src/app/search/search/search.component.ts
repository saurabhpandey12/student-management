import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchService } from './../search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  ngOnInit() {


   
  }
  constructor(private serachService : SearchService){ 
}


students:any
key:any
searchFlag=true
isResultFound=false;
onSubmit(f: NgForm) {
  this.searchFlag=true;
  this.serachService.searchStudentBasedOnField(f.value.first).subscribe((res)=>{
    this.students=res;
    // debugger
    if(this.students==''){
      this.isResultFound=true;
    }
    console.log(this.students);
    
  })
}

  
}
