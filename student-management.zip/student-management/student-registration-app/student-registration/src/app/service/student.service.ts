import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { City } from '../model/City';
import { Country } from '../model/country';
import { State } from '../model/states';

const API_URI="http://localhost:8080";
const END_POINT_BASE_PATH="/student-service/v1"
const STUDENT_REGISTERATION_API="/studentRegistration";
const GET_ALL_COURSE_API="/getAllCourse";

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http:HttpClient) { }

  registerStudentForm(student:any):Observable<any>{
    return this.http.post(API_URI+END_POINT_BASE_PATH+STUDENT_REGISTERATION_API,student);
  }

  getAllCourseList(){
    return this.http.get(API_URI+END_POINT_BASE_PATH+GET_ALL_COURSE_API)
  }

  getStates() {
    return [
      new State('Arizona', 'USA', 'Arizona' ),
      new State('Alaska', 'USA', 'Alaska' ),
      new State('Florida', 'USA', 'Florida'),
      new State('Hawaii', 'Brazil', 'Hawaii'),
      new State('Sao Paulo', 'Brazil', 'Sao Paulo' ),
      new State('Rio de Janeiro', 'Brazil', 'Rio de Janeiro'),
      new State('Minas Gerais', 'Brazil', 'Minas Gerais' )
     ];
   }

   getCity() {
    return [
     new City('USA', 'USA' ),
     new City('Brazil', 'Brazil' ),
    ];
  }
  
  getCountry() {
    return [
     new Country(1, 'india' ),
     new Country(2, 'us' ),
    ];
  }

  getAllStudents(){
    return this.http.get(API_URI+END_POINT_BASE_PATH+'/getAllStudents')
  }

  getStudentById(studentId:number){
    return this.http.get(API_URI+END_POINT_BASE_PATH+'/getStudentById/'+studentId);
  }

    updateStudentDeatils(student:any){
      return this.http.put(API_URI+END_POINT_BASE_PATH+'/updateStudent',student);
    }


}
