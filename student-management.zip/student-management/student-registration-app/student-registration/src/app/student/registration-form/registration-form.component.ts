import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/core/validation.service';
import { City } from 'src/app/model/City';
import { State } from 'src/app/model/states';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {
 


  // address:any
  countrys:any

  constructor(private _formBuilder: FormBuilder,private studentService:StudentService) {}

  ngOnInit() {
    this.getAllCourseList()
    this.city = this.studentService.getCity();
    this.onSelect(this.selectCity.id);
    this.countrys=this.studentService.getCountry();
    
    
  }
  submitted=false;

  personalInfo=this._formBuilder.group({
    address:this._formBuilder.group({
      streetAddress: '',
      state:'',
      city:'',
      pincode:'',
      country:''
    }),
    course:this._formBuilder.group({
      courseName:'',
      courseFee:''
    }),
    firstName:[null,[Validators.required,
      Validators.minLength(2),
      Validators.maxLength(30)]],
    lastName:[null,[Validators.required,
    Validators.minLength(2),
    Validators.maxLength(30)]],
    studentRollNumber:[null,[Validators.required,
    Validators.minLength(4),
    Validators.maxLength(30)]],
    studentEmail: [null,  Validators.required ],
    
    primaryPhoneNumber:['',[Validators.required,
    Validators.minLength(10),
    Validators.maxLength(10)]],
    alternatePhoneNumber:null,
  })
  
isSubmitted=false;

message="";
formFlag=false;
stateObj:any
  submitStudentRegistrationForm(){
    console.log(this.personalInfo.value);
    
    this.submitted = true;
    
console.log(this.personalInfo.value.address.pincode);

    if(this.personalInfo.value.address.pincode=='' || this.personalInfo.value.address.state=='' || this.personalInfo.value.address.city=='')
    {
      this.formFlag=true;
      alert('address input is blank');
          }
    this.studentService.registerStudentForm(this.personalInfo.value).subscribe((res)=>{
      this.isSubmitted=true;
      this.message=res;
      console.log(this.message);
    })
    // this.personalInfo.reset();
  
    if(this.message!=''){
      alert('duplicate roll number')
    }
  }

  courseList:any
  c=false
  getAllCourseList(){
    this.studentService.getAllCourseList().subscribe((res)=>{
      this.courseList=res; 
      this.c=true
    })
  }
  add(){
    this.isSubmitted=false
  }

  selectCity: City = new City('Brazil', 'Brazil');
  city: City[];
  states: State[];

  onSelect(cityId) {
    this.states = this.studentService.getStates().filter((item) => item.cityId == cityId);
  }

 

}
