import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  constructor(private studentService:StudentService,private router:Router) { }

  ngOnInit(): void {
    this.getAllStudents();
  }

  students:any
  stu:any
  searchText=''

  getAllStudents(){
    this.studentService.getAllStudents().subscribe((res)=>{
      this.stu=res;
      this.students=this.stu.content;
      console.log(this.students);
      

    })
  }
  i=0;

  update(studentId:number){
    console.log(studentId);
    
    this.router.navigate(['/student/update',studentId])
  }
  viewDeatils(studentId:number){
    console.log(studentId);
    
    this.router.navigate(['/student/view-details',studentId])
  }
}
