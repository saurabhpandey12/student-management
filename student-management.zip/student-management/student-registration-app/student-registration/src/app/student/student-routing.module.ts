import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { StudentListComponent } from './student-list/student-list.component';

import { StudentComponent } from './student.component';
import { UpdateStudentDetailComponent } from './update-student-detail/update-student-detail.component';
import { ViewStudentDetailsComponent } from './view-student-details/view-student-details.component';

const routes: Routes = [{ path: '', component: StudentComponent},
{
  path:'registration-form',
  component:RegistrationFormComponent
},
{
path:'students',
component:StudentListComponent
}
,
{
  path:'update/:id',
  component:UpdateStudentDetailComponent
},
{
  path:'view-details/:id',
  component:ViewStudentDetailsComponent
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }
