import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentRoutingModule } from './student-routing.module';
import { StudentComponent } from './student.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import { StudentListComponent } from './student-list/student-list.component';
import { UpdateStudentDetailComponent } from './update-student-detail/update-student-detail.component';
import { ViewStudentDetailsComponent } from './view-student-details/view-student-details.component';
import { SearchPipe } from '../shared/search.pipe';


@NgModule({
  declarations: [StudentComponent, RegistrationFormComponent, StudentListComponent, UpdateStudentDetailComponent, ViewStudentDetailsComponent,SearchPipe],
  imports: [
    CommonModule,
    StudentRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    MatButtonModule
  ]
})
export class StudentModule { }
