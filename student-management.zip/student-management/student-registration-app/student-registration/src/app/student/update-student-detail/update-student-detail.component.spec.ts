import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateStudentDetailComponent } from './update-student-detail.component';

describe('UpdateStudentDetailComponent', () => {
  let component: UpdateStudentDetailComponent;
  let fixture: ComponentFixture<UpdateStudentDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateStudentDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateStudentDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
