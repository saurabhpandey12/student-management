import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ValidationService } from 'src/app/core/validation.service';
import { City } from 'src/app/model/City';
import { State } from 'src/app/model/states';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-update-student-detail',
  templateUrl: './update-student-detail.component.html',
  styleUrls: ['./update-student-detail.component.css']
})
export class UpdateStudentDetailComponent implements OnInit,OnDestroy {

  id: number;
  private sub: any;
  student:any
  constructor(private route: ActivatedRoute,private studentService:StudentService,private _formBuilder: FormBuilder) { }

  ngOnInit(): void {
 
    this.sub = this.route.params.subscribe(params => {

      this.id = +params['id']; // (+) converts string 'id' to a number
      console.log(this.id);

   });
   this.getStudentById(this.id);
   this.getAllCourseList()
   this.city = this.studentService.getCity();
   this.onSelect(this.selectCity.id);
   this.countrys=this.studentService.getCountry();
   
   
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  isDataLoaded=false;

  getStudentById(id:number){

    this.studentService.getStudentById(this.id).subscribe((res)=>{
      this.student=res;
      this.isDataLoaded=true;
      console.log(this.student);
      
    })
  }


          
  // address:any
  countrys:any

  submitted=false;

  personalInfo=this._formBuilder.group({
    address:this._formBuilder.group({
      streetAddress: null,
      state:null,
      city:'',
      pincode:'',
      country:''
    }),
    course:this._formBuilder.group({
      courseName:'',
      courseFee:''
    }),
    studentId:[null],
    firstName:[null,[Validators.required,
      Validators.minLength(2),
      Validators.maxLength(30)]],
    lastName:[null,Validators.required,
    Validators.minLength(2),
    Validators.maxLength(30)],
    studentRollNumber:[null,[Validators.required,
    Validators.minLength(4),
    Validators.maxLength(30)]],
    studentEmail: [null, [ Validators.required ]],
    
    primaryPhoneNumber:['',[Validators.required,
    Validators.minLength(10),
    Validators.maxLength(10)]],
    alternatePhoneNumber:null,
  })
  
isSubmitted=false;

message="";
formFlag=false;
stateObj:any
  submitStudentRegistrationForm(){
    console.log(this.personalInfo.value);
    
    this.submitted = true;
    
console.log(this.personalInfo.value.address.pincode);

    if(this.personalInfo.value.address.pincode=='' || this.personalInfo.value.address.state=='' || this.personalInfo.value.address.city=='')
    {
      this.formFlag=true;
      alert('address input is blank');
          }
    this.studentService.updateStudentDeatils(this.personalInfo.value).subscribe((res)=>{
      this.isSubmitted=true;
     
      console.log(this.message);
    })
    // this.personalInfo.reset();
  
    if(this.message!=''){
      alert('duplicate roll number')
    }
  }

  courseList:any
  c=false
  getAllCourseList(){
    this.studentService.getAllCourseList().subscribe((res)=>{
      this.courseList=res; 
      this.c=true
    })
  }
  add(){
    this.isSubmitted=false
  }

  selectCity: City = new City('Brazil', 'Brazil');
  city: City[];
  states: State[];

  onSelect(cityId) {
    this.states = this.studentService.getStates().filter((item) => item.cityId == cityId);
  }






}
