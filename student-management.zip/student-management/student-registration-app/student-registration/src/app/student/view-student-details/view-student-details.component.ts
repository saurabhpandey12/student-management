import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-view-student-details',
  templateUrl: './view-student-details.component.html',
  styleUrls: ['./view-student-details.component.css']
})
export class ViewStudentDetailsComponent implements OnInit ,OnDestroy{

 
  id: number;
  private sub: any;
  student:any
  constructor(private route: ActivatedRoute,private studentService:StudentService) { }
  isStudentDeatilLoaded=false;
  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number

      // In a real app: dispatch action to load the details here.
   });
   this.isStudentDeatilLoaded=true;
   this.getStudentById();
   
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }


  getStudentById(){
    this.studentService.getStudentById(this.id).subscribe((res)=>{
      this.student=res;
    })
  }
  getStudentDetailsByID(id:number){
    this.studentService.getStudentById(id).subscribe((res)=>{
      this.student=res;
    },
    (err)=>{
console.log('no data is available with this id');

    }
    )
  }

}
