package com.tatastrive.studentregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentregistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentregistrationApplication.class, args);
	}

}
