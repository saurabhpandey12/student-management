
package com.tatastrive.studentregistration.controller;

public   class ControllerConstants {
	
	public final static String END_POINT_BASE_PATH="/student-service/v1";
	
	public final static String STUDENT_REGISTRATION="/studentRegistration";
	
	public final static String GET_ALL_COURSE="/getAllCourse";
	
	public final static String GET_COUSRSE_FEE_BY_ID="/getCourseFeeById";
	
	public final static String GET_ALL_STUDENTS="/getAllStudents";
	
	public final static String GET_STUDENT_BY_ID="/getStudentById/{studentId}";
	
	public final static String SEARCH_STUDENTS_BASED_ON_FIELDS="/searchStudentsBasedOnFields/{searchKey}";
	
	public final static String UPDATE_STUDENT="/updateStudent";
	
	public final static String DELETE_STUDENT_BY_ID="/deleteStudentById/{studentId}";
	
	

}
