package com.tatastrive.studentregistration.controller;

import static com.tatastrive.studentregistration.controller.ControllerConstants.END_POINT_BASE_PATH;
import static com.tatastrive.studentregistration.controller.ControllerConstants.STUDENT_REGISTRATION;
import static com.tatastrive.studentregistration.controller.ControllerConstants.GET_ALL_COURSE;
import static com.tatastrive.studentregistration.controller.ControllerConstants.GET_ALL_STUDENTS;
import static com.tatastrive.studentregistration.controller.ControllerConstants.GET_STUDENT_BY_ID;
import static com.tatastrive.studentregistration.controller.ControllerConstants.DELETE_STUDENT_BY_ID;
import static com.tatastrive.studentregistration.controller.ControllerConstants.UPDATE_STUDENT;
import static com.tatastrive.studentregistration.controller.ControllerConstants.SEARCH_STUDENTS_BASED_ON_FIELDS;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tatastrive.studentregistration.exception.DuplicateRollNumberException;
import com.tatastrive.studentregistration.model.Course;
import com.tatastrive.studentregistration.model.Student;
import com.tatastrive.studentregistration.service.StudentService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(END_POINT_BASE_PATH)
@RestController
public class StudentRegistrationController {

	@Autowired
	private StudentService studentService;

	@PostMapping(STUDENT_REGISTRATION)
	boolean createStudentRegistration(@RequestBody Student student) {
		String message = "";
		boolean isRegistered=true;
		try {
		studentService.createStudentRegistration(student, 1);
		isRegistered=false;

		} catch (DuplicateRollNumberException e) {
			System.err.println("duplicate roll number");
			message = e.getMessage();
			isRegistered=true;
		}
		return isRegistered;
	}

	@GetMapping(GET_ALL_COURSE)
	List<Course> getAllCourse() {

		return studentService.getAllCourseList();

	}

	@GetMapping(GET_ALL_STUDENTS)
	Page<Student> getAllStudent(Pageable pageable) {
		return studentService.getAllStudentList(pageable);

	}

	@GetMapping(GET_STUDENT_BY_ID)
	Student getStudentById(@PathVariable int studentId) {
		Student student = studentService.getStudentById(studentId);
		System.err.println(student);
		return student;
	}

	@PutMapping(UPDATE_STUDENT)
	void updateStudent(@RequestBody Student student) {
		studentService.updateStudent(student);
	}

	@DeleteMapping(
			DELETE_STUDENT_BY_ID
			)
	void deleteStudentById(@PathVariable int studentId) {

	}

	@GetMapping(SEARCH_STUDENTS_BASED_ON_FIELDS)
	List<Student> searchStuentBasedOnField(@PathVariable String searchKey, Pageable pageable) {
		return studentService.searchStudentBasedOnField(searchKey, pageable);
	}

}
