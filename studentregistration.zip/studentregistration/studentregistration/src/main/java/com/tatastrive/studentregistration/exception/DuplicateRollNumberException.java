package com.tatastrive.studentregistration.exception;

public class DuplicateRollNumberException extends RuntimeException {
	
	public DuplicateRollNumberException(String msz) {
		super(msz);
		// TODO Auto-generated constructor stub
	}

}
