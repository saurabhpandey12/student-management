package com.tatastrive.studentregistration.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int studentId;
	private String firstName;
	private String lastName;
	private String studentRollNumber;
	private String studentEmail;
	private String primaryPhoneNumber;
	private String alternatePhoneNumber;
//	@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="student")
	private Address address;
	@OneToOne
	private Course course;
	
	
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStudentRollNumber() {
		return studentRollNumber;
	}
	public void setStudentRollNumber(String studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public String getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}
	public void setPrimaryPhoneNumber(String primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}
	public String getAlternatePhoneNumber() {
		return alternatePhoneNumber;
	}
	public void setAlternatePhoneNumber(String alternatePhoneNumber) {
		this.alternatePhoneNumber = alternatePhoneNumber;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", studentRollNumber=" + studentRollNumber + ", studentEmail=" + studentEmail
				+ ", primaryPhoneNumber=" + primaryPhoneNumber + ", alternatePhoneNumber=" + alternatePhoneNumber
				+ ", address=" + address + ", course=" + course + ", getAddress()=" + getAddress() + ", getCourse()="
				+ getCourse() + ", getStudentId()=" + getStudentId() + ", getFirstName()=" + getFirstName()
				+ ", getLastName()=" + getLastName() + ", getStudentRollNumber()=" + getStudentRollNumber()
				+ ", getStudentEmail()=" + getStudentEmail() + ", getPrimaryPhoneNumber()=" + getPrimaryPhoneNumber()
				+ ", getAlternatePhoneNumber()=" + getAlternatePhoneNumber() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
	
	
	
	

}
