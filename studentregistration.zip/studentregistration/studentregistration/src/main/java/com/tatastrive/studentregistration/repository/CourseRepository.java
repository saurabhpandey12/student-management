package com.tatastrive.studentregistration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tatastrive.studentregistration.model.Course;

public interface CourseRepository extends JpaRepository<Course, Integer> {
	Course findCourseByCourseName(String courseName);
	Course findCourseById(int courseId);
	

}
