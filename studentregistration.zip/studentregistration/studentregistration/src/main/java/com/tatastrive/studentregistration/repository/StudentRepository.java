package com.tatastrive.studentregistration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tatastrive.studentregistration.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{
	
	Student findStudentByStudentId(int studentId);
	

}
