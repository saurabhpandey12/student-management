package com.tatastrive.studentregistration.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tatastrive.studentregistration.model.Course;
import com.tatastrive.studentregistration.model.Student;

public interface StudentService {

	boolean createStudentRegistration(Student student, int courseId);

	List<Course> getAllCourseList();

	Page<Student> getAllStudentList(Pageable pageable);
	
	Student getStudentById(int studentId);
	
	void updateStudent(Student student);
	
	void deleteStudentById(int studentId);
	
	List<Student> searchStudentBasedOnField(String searchKey,Pageable pageable);

}
