package com.tatastrive.studentregistration.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.tatastrive.studentregistration.exception.DuplicateRollNumberException;
import com.tatastrive.studentregistration.model.Address;
import com.tatastrive.studentregistration.model.Course;
import com.tatastrive.studentregistration.model.Student;
import com.tatastrive.studentregistration.repository.CourseRepository;
import com.tatastrive.studentregistration.repository.StudentRepository;
import com.tatastrive.studentregistration.util.JPAUtil;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public boolean createStudentRegistration(Student student, int courseId) {
		System.out.println(student + "" + student.getAddress());
		Address address = student.getAddress();
		System.out.println(address);
		address.setStudent(student);
		student.setAddress(address);
		boolean flag = false;
		List<Student> studentList = studentRepository.findAll();
		for (Student stu : studentList) {
			if (stu.getStudentRollNumber().equals(student.getStudentRollNumber())) {
				flag = true;
				throw new DuplicateRollNumberException("roll number already taken");

			}
		}
		Course course = courseRepository.findCourseByCourseName(student.getCourse().getCourseName());
		student.setCourse(course);
		if (!flag) {
			studentRepository.save(student);
		} else {
			return false;
		}
		return flag;

	}

	public List<Course> getAllCourseList() {
		return courseRepository.findAll();
	}

	@Override
	public Page<Student> getAllStudentList(Pageable pageable) {

		Page<Student> getAllStudentList = studentRepository.findAll(pageable);

		return getAllStudentList;
	}

	@Override
	public Student getStudentById(int studentId) {
		Student studentObj =new Student();
		List<Student> studentList=studentRepository.findAll();
		System.err.println(studentList);
		for(Student student : studentList) {
			if(student.getStudentId()==studentId) {
				studentObj=student;
				break;
			}
		}
		return studentObj;
	}

	@Override
	public void updateStudent(Student student) {
		System.err.println(student);
		Optional<Student> studentObj=studentRepository.findById(student.getStudentId());
		System.err.println(student.getStudentId());
		Student studentUpdateObj=new Student();
		if(studentObj.isPresent()) {
			studentUpdateObj.setStudentId(studentObj.get().getStudentId());
			studentUpdateObj.setAddress(student.getAddress());
			Course course=courseRepository.findCourseById(studentObj.get().getCourse().getId());
			studentUpdateObj.setCourse(course);
			studentUpdateObj.setFirstName(student.getFirstName());
			studentUpdateObj.setLastName(student.getLastName());
			studentUpdateObj.setPrimaryPhoneNumber(student.getPrimaryPhoneNumber());
			studentUpdateObj.setAlternatePhoneNumber(student.getAlternatePhoneNumber());
			studentUpdateObj.setStudentRollNumber(student.getStudentRollNumber());
			studentUpdateObj.setStudentEmail(student.getStudentEmail());
		}
		studentRepository.save(studentUpdateObj);

	}

	@Override
	public void deleteStudentById(int studentId) {
		studentRepository.deleteById(studentId);
	}

	@Override
	public List<Student> searchStudentBasedOnField(String searchKey, Pageable pageable) {
		Page<Student> studentList = studentRepository.findAll(pageable);
		String strArr = searchKey;
		String[] strgs = strArr.split(" ");
		List<String> strList = new ArrayList<String>();
		List<Student> filteredStudentList = new ArrayList<>();
		for (String str : strgs) {
			strList.add(str);
		}
		for (Student student : studentList) {
			int num =0;
			for (String key : strList) {
				try{
					   num = Integer.parseInt(key);
					} catch (NumberFormatException e) {
					}
				if (student.getFirstName().equals(key) || student.getLastName().equals(key)
						|| student.getStudentRollNumber().equals(key) || student.getStudentEmail().equals(key)
						|| student.getCourse().equals(key)
						|| student.getAddress().getPincode() == num) {
					filteredStudentList.add(student);

				}
			}
		}

		return filteredStudentList;

	}

}
